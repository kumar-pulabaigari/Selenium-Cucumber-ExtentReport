package cucumberStepDefinitions;

import com.relevantcodes.extentreports.LogStatus;
import commonFunctions.CommonBehaviour;
import commonFunctions.loadPropertyFile;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import extentReport.ExtentTestManager;
import frameworkUtili.driver;
import frameworkUtili.testData;
import org.openqa.selenium.WebDriver;

/**
 * Created by Vinay on 6/30/2017.
 */
public class loginStepDefs {
    CommonBehaviour  comm = new CommonBehaviour();

    @Given("^Open the Login Url$")
    public void selectTheBrowser() throws Throwable {
        System.out.println("User is on " + getClass().toString());
        driver wDriver= new driver();
        WebDriver driver= wDriver.getDriver();
        loadPropertyFile applicationProperty= new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        comm.reportScreenshot(driver);
    }

    @When("^Enter the credentials and click on sign on button$")
    public void Enter_the_credentials_and_click_onsign_onbutton (){
        driver wDriver= new driver();
        WebDriver driver= wDriver.getDriver();
        testData data=new testData();
        new pages.ptrinfosys.loginPage().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        ExtentTestManager.write(LogStatus.INFO, "Title " , "Title is " +driver.getTitle());
        comm.reportScreenshot(driver);
    }

    @Then("^Login should be successful$")
    public void Login_should_be_successful() {
        driver wDriver= new driver();
        WebDriver driver= wDriver.getDriver();
        new pages.ptrinfosys.loginPage().succesfullSignOn();
        comm.reportScreenshot(driver);
    }

    @Then("^Login should not be successful$")
    public void Login_should_not_be_successful() {
        driver wDriver= new driver();
        WebDriver driver= wDriver.getDriver();
        new pages.ptrinfosys.loginPage().unsuccesfullSignOn();
        comm.reportScreenshot(driver);
    }

    @And("^Click on Sign Out$")
    public void Click_onSign_Out() {
        driver wDriver= new driver();
        WebDriver driver= wDriver.getDriver();
        new pages.ptrinfosys.loginPage().signOut();
        comm.reportScreenshot(driver);
    }

}
