package pages.hcmapplication;

import com.relevantcodes.extentreports.LogStatus;
import commonFunctions.CommonBehaviour;
import extentReport.ExtentTestManager;
import frameworkUtili.driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class login {
    private CommonBehaviour commBeh = new CommonBehaviour();
    private By loginUserID = By.id("userid");
    private By loginPassword = By.id("password");
    private By loginSingIn =By.xpath("//button[@type='submit']");
    private By visionTitle= By.xpath("//*[@id='pt1:_UIScil1u']");

    public boolean signOn(String userName,String password){
        ExtentTestManager.write(LogStatus.INFO, "Step 1","scenario started...");
        driver wDriver= new driver();
        WebDriver driver= wDriver.getDriver();
        commBeh.type("Login User Name", loginUserID,driver,userName);
        commBeh.type("Login Password", loginPassword,driver,password);
        commBeh.screenshot(driver);
        commBeh.click("Login signIn button", loginSingIn, driver);
        commBeh.reportScreenshot(driver);
        return commBeh.isExist(driver, visionTitle);
    }



}
