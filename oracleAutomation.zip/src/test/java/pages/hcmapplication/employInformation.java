package pages.hcmapplication;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import commonFunctions.CommonBehaviour;
import extentReport.ExtentTestManager;
import frameworkUtili.driver;
import org.apache.regexp.RE;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Created by Sreehari_M on 7/12/2017.
 */
public class employInformation {
    private CommonBehaviour commBeh = new CommonBehaviour();
    private frameworkUtili.driver wDriver= new driver();
    private WebDriver driver= wDriver.getDriver();
    private By actionButton=By.xpath("//button[span[contains(text(), 'Actions')]]");
    private By actionDropDownItems(String name){
        return By.xpath("//tr[contains(@id, '_FOpt1:_FOr1:0')] [td[contains(text(), '"+name+"')]]");
    }
    private By deleteExistingSavedOnes=By.id("_FOpt1:_FOr1:0:_FOSrPER_HCMPEOPLETOP_FUSE_MY_TEAM:0:MAnt2:1:AP1:cl2");

    private String actionList[] = {"Change Location", "Change Manager", "Change Working Hours", "Compare", "Information Sharing", "Manage Allocated Checklists", "Manage Direct Reports",
    "Manage Document Records", "Manage Person", "Manage Person Identifiers for External Applications", "Manage User Account", "Promote", "Terminate", "Transfer"};

    public boolean actionListPersonalAndEmployment(){
        if(commBeh.isExist(driver,actionButton )){
            commBeh.click("Action Button", actionButton, driver);
            if(commBeh.isExist(driver,actionDropDownItems("Personal and Employment") )){
                commBeh.click("Personal and Employment", actionDropDownItems("Personal and Employment"), driver);
            }
        }

        for (String action:actionList) {
            if(commBeh.isExist(driver,actionDropDownItems(action) )){
                ExtentTestManager.write(LogStatus.PASS, action +" item  is getting displayed");
            } else {
                ExtentTestManager.write(LogStatus.FAIL, action +" item  is not getting displayed");
            }
        }
        commBeh.reportScreenshot(driver);
        return true;
    }

    public boolean navigateManageSalary() {
        if (commBeh.isExist(driver, actionButton)) {
            commBeh.click("Action Button", actionButton, driver);
            if (commBeh.isExist(driver, actionDropDownItems("Compensation"))) {
                commBeh.click("Compensation", actionDropDownItems("Compensation"), driver);
                if (commBeh.isExist(driver, actionDropDownItems("Manage Salary"))) {
                    commBeh.click("Manage Salary", actionDropDownItems("Manage Salary"), driver);
                }
            }
        }
        if(commBeh.isExist(driver, deleteExistingSavedOnes)){
            commBeh.click("Delete the Saved Transaction and Start a New One", deleteExistingSavedOnes, driver);
        }

        return true;
    }

    public boolean navigateChangeLocation() {
        if (commBeh.isExist(driver, actionButton)) {
            commBeh.click("Action Button", actionButton, driver);
            if (commBeh.isExist(driver, actionDropDownItems("Personal and Employment"))) {
                commBeh.click("Personal and Employment", actionDropDownItems("Personal and Employment"), driver);
                if (commBeh.isExist(driver, actionDropDownItems("Change Location"))) {
                    commBeh.click("Manage Salary", actionDropDownItems("Change Location"), driver);
                }
            }
        }
        if(commBeh.isExist(driver, deleteExistingSavedOnes)){
            commBeh.click("Delete the Saved Transaction and Start a New One", deleteExistingSavedOnes, driver);
        }

        return true;
    }
}
