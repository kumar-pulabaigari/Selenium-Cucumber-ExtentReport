package pages.hcmapplication;

import commonFunctions.CommonBehaviour;
import frameworkUtili.driver;
import frameworkUtili.testData;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Created by Sreehari_M on 7/12/2017.
 */
public class manageSalary {
    private CommonBehaviour commBeh = new CommonBehaviour();
    private frameworkUtili.driver wDriver= new driver();
    private WebDriver driver= wDriver.getDriver();
    testData data=new testData();

    private By newSalaryStartDate =By.xpath("//input[contains(@id, 'idEffectiveFromDate::content')]");

    private By actionDDL=By.xpath("//input[contains(@id, 'idAction::content')]");
    private By actionReasonDDL=By.xpath("//input[contains(@id, 'actionReasonNameId::content')]");

    private By saveButton=By.xpath("//a[span[contains(text(), 'Save')]]");

    private By confirmationOk =By.xpath("//*[contains(@id,'okConfirmationDialog')]");
    private By confirmationCancel = By.id("_FOpt1:_FOr1:0:_FOSrPER_HCMPEOPLETOP_FUSE_MY_TEAM:0:MAnt2:1:ap1:txnt2:confirmationDialog::close");
    public boolean modifyDetails(){
        String NewSalaryStartDate = data.getTestData("New Salary Start Date") ;
        String Action= data.getTestData("Action");
        String ActionReason = data.getTestData("Action Reason");

        if( NewSalaryStartDate != ""){
            if(commBeh.isExist(driver, newSalaryStartDate)){
                driver.findElement(newSalaryStartDate).clear();
                commBeh.type("New Salary Start Date", newSalaryStartDate, driver, NewSalaryStartDate);
            }
        }

        if( Action != ""){
            if(commBeh.isExist(driver, actionDDL)){
                driver.findElement(actionDDL).clear();
                commBeh.type("Action", actionDDL, driver, Action);
            }
        }

        if( ActionReason != ""){
            if(commBeh.isExist(driver, actionReasonDDL)){
                driver.findElement(actionReasonDDL).clear();
                commBeh.type("Action Reason", actionReasonDDL, driver, ActionReason);
            }
        }

        commBeh.click("Save button",saveButton, driver );

        commBeh.click("Confirmation Ok button",confirmationOk, driver );

        return true;
    }
}
