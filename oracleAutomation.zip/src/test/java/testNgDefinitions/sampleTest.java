package testNgDefinitions;

import com.relevantcodes.extentreports.LogStatus;
import commonFunctions.loadPropertyFile;
import extentReport.ExtentTestManager;
import frameworkUtili.configurationManager;
import frameworkUtili.driver;
import frameworkUtili.testData;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.Test;

/**
 * Created by Vinay on 5/13/2017.
 */
public class sampleTest extends testNGMaster{

//    @Test
    public void test1(ITestContext context){
        before("Change Location Action Reasons - Pick list Validation");
        driver wDriver= new driver();
        WebDriver driver= wDriver.getDriver();
        testData data=new testData();

        loadPropertyFile applicationProperty= new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window= driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        for (String windowHandler:driver.getWindowHandles() ){
            if(Parent_Window != windowHandler){
                driver.switchTo().window(windowHandler);
            }
        }

        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));

        new pages.hcmapplication.employInformation().actionListPersonalAndEmployment();
        new pages.hcmapplication.homePage().signOut();
    }

    @Test
    public void test2(ITestContext context){
        before("Verify that all  Manage Salary Action are avaliable to choose");
        driver wDriver= new driver();
        WebDriver driver= wDriver.getDriver();
        testData data=new testData();

        loadPropertyFile applicationProperty= new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window= driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        for (String windowHandler:driver.getWindowHandles() ){
            if(Parent_Window != windowHandler){
                driver.switchTo().window(windowHandler);
            }
        }

        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));

        new pages.hcmapplication.employInformation().navigateManageSalary();
        new pages.hcmapplication.manageSalary().modifyDetails();

        new pages.hcmapplication.homePage().signOut();
    }

    @Test
    public void test3(ITestContext context){
        before("Verify the Location Change of an Associate to any of the US offices");
        driver wDriver= new driver();
        WebDriver driver= wDriver.getDriver();
        testData data=new testData();

        loadPropertyFile applicationProperty= new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseURL"));
        String Parent_Window= driver.getWindowHandle();
        new pages.hcmapplication.mainHtml().navigateToHCMLoginPage();
        for (String windowHandler:driver.getWindowHandles() ){
            if(Parent_Window != windowHandler){
                driver.switchTo().window(windowHandler);
            }
        }

        new pages.hcmapplication.login().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        new pages.hcmapplication.homePage().navigateToMyTeam();
        new pages.hcmapplication.homePage().teamMemberSelection(data.getTestData("Team Member"));

        new pages.hcmapplication.employInformation().navigateManageSalary();
        new pages.hcmapplication.changeLocation().modifyDetails();

        new pages.hcmapplication.homePage().signOut();
    }
}
