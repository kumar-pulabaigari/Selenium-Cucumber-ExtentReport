package pages.ptrinfosys;

import com.relevantcodes.extentreports.LogStatus;
import commonFunctions.CommonBehaviour;
import extentReport.ExtentTestManager;
import frameworkUtili.driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class loginPage {
    private CommonBehaviour commBeh = new CommonBehaviour();
    private By loginUserID = By.id("dialogTemplate-dialogForm-content-login-name1");
    private By loginPassword = By.id("dialogTemplate-dialogForm-content-login-password");
    private By loginSingOn =By.id("dialogTemplate-dialogForm-content-login-defaultCmd");
    private By homeIcon = By.id("dailogHome");
    public boolean signOn(String userName,String password){
        ExtentTestManager.write(LogStatus.INFO, "Step 1","scenario started...");
        driver wDriver= new driver();
        WebDriver driver= wDriver.getDriver();
        commBeh.type("Login User Name", loginUserID,driver,userName);
        commBeh.type("Login Password", loginPassword,driver,password);
        commBeh.click("Login signon button", loginSingOn, driver);
        return true;
    }

    public boolean unsuccesfullSignOn(){
        driver wDriver= new driver();
        WebDriver driver= wDriver.getDriver();
        if(commBeh.isExist(driver, loginUserID)){
            ExtentTestManager.write(LogStatus.PASS, "Login", " is Successful");
        } else {
            ExtentTestManager.write(LogStatus.PASS, "Login", "is not Successful");
        }
        return true;
    }

    public boolean succesfullSignOn(){
        driver wDriver= new driver();
        WebDriver driver= wDriver.getDriver();
        if(commBeh.isExist(driver, homeIcon)){
            ExtentTestManager.write(LogStatus.PASS, "Login", " is Successful");
        } else {
            ExtentTestManager.write(LogStatus.PASS, "Login", "is not Successful");
        }
        return true;
    }
}
