package testNgDefinitions;

import com.relevantcodes.extentreports.LogStatus;
import commonFunctions.loadPropertyFile;
import extentReport.ExtentTestManager;
import frameworkUtili.configurationManager;
import frameworkUtili.driver;
import frameworkUtili.testData;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.Test;

/**
 * Created by Vinay on 5/13/2017.
 */
public class sampleTest extends testNGMaster{

    @Test
    public void test1(ITestContext context){
        before("Sample Test Case");
        driver wDriver= new driver();
        WebDriver driver= wDriver.getDriver();
        testData data=new testData();
        loadPropertyFile applicationProperty= new loadPropertyFile("/resources/application.properties");
        driver.get(applicationProperty.getPropertyValue("env.baseurl"));
        new pages.ptrinfosys.loginPage().signOn(data.getTestData("User Name"), data.getTestData("User Password"));
        ExtentTestManager.write(LogStatus.INFO, "Title " ,driver.getTitle());
        new pages.ptrinfosys.loginPage().succesfullSignOn();
        new pages.ptrinfosys.loginPage().signOut();
    }
}
