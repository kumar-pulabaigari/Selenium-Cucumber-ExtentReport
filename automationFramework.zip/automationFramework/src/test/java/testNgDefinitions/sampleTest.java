package testNgDefinitions;

import com.relevantcodes.extentreports.LogStatus;
import extentReport.ExtentTestManager;
import frameworkUtili.configurationManager;
import frameworkUtili.driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.Test;

/**
 * Created by Vinay on 5/13/2017.
 */
public class sampleTest extends testNGMaster{

    @Test
    public void test1(ITestContext context){
        before("Test case name");
        driver wDriver= new driver();
        WebDriver driver= wDriver.getDriver();
        driver.get("https://ptrinfosys.taleo.net");
        new pages.ptrinfosys.loginPage().signOn("sunil_surendran@infosys.com", "Taleo123");
        ExtentTestManager.write(LogStatus.INFO, "Title " ,driver.getTitle());
        System.out.println("Paramter Value: " + context.getCurrentXmlTest().getParameter("browserName"));
    }
}
