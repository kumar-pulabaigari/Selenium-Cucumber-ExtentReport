package testNgDefinitions;

import com.relevantcodes.extentreports.LogStatus;
import extentReport.ExtentTestManager;
import frameworkUtili.configurationManager;
import frameworkUtili.driver;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.Test;

/**
 * Created by Vinay on 5/13/2017.
 */
public class sampleTest extends testNGMaster{

    @Test
    public void test1(ITestContext context){
        before("Test case name");
        driver wDriver= new driver();
        WebDriver driver= wDriver.getDriver();
        driver.get("http://google.com");
        ExtentTestManager.write(LogStatus.INFO, driver.getTitle());
        System.out.println("Paramter Value: " + context.getCurrentXmlTest().getParameter("browserName"));
    }
}
