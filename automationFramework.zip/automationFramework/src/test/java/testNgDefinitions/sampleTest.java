package testNgDefinitions;

import com.relevantcodes.extentreports.LogStatus;
import extentReport.ExtentTestManager;
import frameworkUtili.configurationManager;
import org.testng.ITestContext;
import org.testng.annotations.Test;

/**
 * Created by Vinay on 5/13/2017.
 */
public class sampleTest extends testNGMaster{

    @Test
    public void test1(ITestContext context){
        before("Test case name");
        configurationManager.getRemoteWebDriver().get("http://google.com");
        ExtentTestManager.write(LogStatus.INFO, configurationManager.getRemoteWebDriver().getTitle());
        System.out.println("Paramter Value: " + context.getCurrentXmlTest().getParameter("browserName"));
    }
}
