package testNgDefinitions;

import com.relevantcodes.extentreports.LogStatus;
import extentReport.ExtentManager;
import extentReport.ExtentTestManager;
import frameworkUtili.configurationManager;
import frameworkUtili.driver;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.*;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;

public class testNGMaster{

    @BeforeClass(alwaysRun = true)
    public void setUpClass(ITestContext context) throws Exception {
        ExtentTestManager.extent = ExtentManager.getReporter();
        configurationManager.setITestContext(context);
    }


    void before(String testCaseName) {
        String finalTestCaseName ="";
        Collection<String> category = new ArrayList<String>();
        ITestContext context= configurationManager.getITestContext();
        ExtentTestManager.extent = ExtentManager.getReporter();
        int count=1;
        try {
            if (!context.getCurrentXmlTest().getParameter("automationName").isEmpty()) {
                finalTestCaseName = context.getCurrentXmlTest().getParameter("automationName") + "_";
                finalTestCaseName.trim();
                category.add(context.getCurrentXmlTest().getParameter("automationName"));
            }
        }catch (Exception ex){

        }

        try{
            if(! context.getCurrentXmlTest().getParameter("environmentName").isEmpty()){
                finalTestCaseName= finalTestCaseName+ context.getCurrentXmlTest().getParameter("environmentName") + "_";
                category.add(context.getCurrentXmlTest().getParameter("environmentName"));
                finalTestCaseName.trim();
            }
        }catch (Exception ex){

        }

        try{
            if(! context.getCurrentXmlTest().getParameter("browserName").isEmpty()){
                finalTestCaseName= finalTestCaseName+ context.getCurrentXmlTest().getParameter("browserName");
                finalTestCaseName.trim();
                category.add(context.getCurrentXmlTest().getParameter("browserName"));
            }
        }catch (Exception ex){

        }

        try{
            if(testCaseName.trim().isEmpty()) {
                finalTestCaseName= testCaseName;
            } else {
                finalTestCaseName= finalTestCaseName+ "_"+ testCaseName;
            }
        }catch (Exception ex){

        }

        do {
            if(configurationManager.testCaseNameList.contains(finalTestCaseName+ "_" + count)) {
                count++;
            }else{
                configurationManager.testCaseNameList.add(finalTestCaseName+ "_" + count);
                ExtentTestManager.startTest(finalTestCaseName+ "_" + count);
                break;
            }
        }while(true);
        ExtentTestManager.assignCategory(category);
        ExtentTestManager.getTest().log(LogStatus.INFO, "Test case started..." + testCaseName);
        FolderName(testCaseName, context);
    }

    @AfterMethod
    public void after(ITestResult iResult) {
        if (! iResult.isSuccess()) {
            ExtentTestManager.write(LogStatus.FAIL, "Test case failed");
        } else {
            ExtentTestManager.write(LogStatus.PASS, "Test case passed");
        }
        ExtentManager.getReporter().endTest(ExtentTestManager.getTest());
        ExtentManager.getReporter().flush();
    }

    @AfterTest
    public void afterTest(){
        ITestContext context = configurationManager.getITestContext();
        String browserName = context.getCurrentXmlTest().getParameter("browserName");
        if(browserName.contains("remote") || browserName.contains("Remote")){
            WebDriver driver=configurationManager.getRemoteWebDriver();
            if(driver != null){
                driver.quit();
                configurationManager.setRemoteWebDriverMap(null);
            }
        } else {
            WebDriver driver=configurationManager.getWebDriver();
            if(driver != null){
                driver.quit();
                configurationManager.setWebDriverMap(null);
            }
        }
    }

    boolean FolderName(String testCaseName, ITestContext context) {
        String baseFolderPath = extentReport.ExtentManager.folderPath();
//        ITestContext context = configurationManager.getITestContext();
        int count=1;
        String screenShotPath ="";
        try{
            if(! context.getCurrentXmlTest().getParameter("automationName").isEmpty()){
                screenShotPath= context.getCurrentXmlTest().getParameter("automationName") + "\\";
                screenShotPath=screenShotPath.trim();
            }
        }catch(Exception ex){

        }

        try{
            if(! context.getCurrentXmlTest().getParameter("environmentName").isEmpty()){
                screenShotPath= context.getCurrentXmlTest().getParameter("environmentName") + "\\";
                screenShotPath=screenShotPath.trim();
            }
        }catch(Exception ex){

        }

        try{
            if(! context.getCurrentXmlTest().getParameter("browserName").isEmpty()){
                screenShotPath= context.getCurrentXmlTest().getParameter("browserName") + "\\";
                screenShotPath=screenShotPath.trim();
            }
        }catch(Exception ex){

        }

        try{
            if(screenShotPath.trim().isEmpty()) {
                screenShotPath= testCaseName;
            } else {
                screenShotPath = screenShotPath + testCaseName;
            }
        }catch(Exception ex){

        }

        do {
            if(configurationManager.screenShotPathList.contains(screenShotPath+ "_" + count)) {
                count++;
            }else{
                configurationManager.screenShotPathList.add(screenShotPath+ "_" + count);
                configurationManager.setScreenShotPath(screenShotPath+ "_" + count);
                break;
            }
        }while(true);

        return true;
    }
}