package frameworkUtili;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestContext;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class configurationManager {
    static Map<Integer, String> screenShotPathMap = new HashMap<Integer, String>();
    static Map<Integer, ITestContext> iTestContextMap = new HashMap<Integer, ITestContext>();
    static Map<Integer, String> testCaseNameMap = new HashMap<Integer, String>();
    static Map<Integer, RemoteWebDriver> remoteWebDriverMap = new HashMap<Integer, RemoteWebDriver>();
    static Map<Integer, WebDriver> webDriverMap = new HashMap<Integer, WebDriver>();
    public static List<String> testCaseNameList = new ArrayList<String>();
    public static List<String> screenShotPathList = new ArrayList<String>();
    static Map<Integer, Map<String, String>> testDataMap = new HashMap<>();

    public static synchronized Map<String, String> getTestDataMap(){
        return testDataMap.get((int) (long) (Thread.currentThread().getId()));
    }

    public static synchronized String getParameter(String parameterName){
        String value="";
        try{
            ITestContext context = configurationManager.getITestContext();
            value=context.getCurrentXmlTest().getParameter(parameterName);
        }catch(Exception ex){

        }
        return value;
    }

    public static synchronized String getScreenShotPath() {
        return screenShotPathMap.get((int) (long) (Thread.currentThread().getId()));
    }

    public static synchronized void setScreenShotPath(String folderPath) {
        screenShotPathMap.put((int) (long) (Thread.currentThread().getId()), folderPath);
    }

    public static synchronized ITestContext getITestContext() {
        return iTestContextMap.get((int) (long) (Thread.currentThread().getId()));
    }

    public static synchronized void setTestDataMap(Map<String, String> map){
        testDataMap.put((int) (long) (Thread.currentThread().getId()), map);
    }

    public static synchronized void setITestContext(ITestContext context) {
        iTestContextMap.put((int) (long) (Thread.currentThread().getId()), context);
    }

    public static synchronized String getTestCaseName() {
        return testCaseNameMap.get((int) (long) (Thread.currentThread().getId()));
    }

    public static synchronized void setTestCaseName(String testCaseName) {
        testCaseNameMap.put((int) (long) (Thread.currentThread().getId()), testCaseName);
    }

    public static synchronized RemoteWebDriver getRemoteWebDriver() {
        return remoteWebDriverMap.get((int) (long) (Thread.currentThread().getId()));
    }

    public static synchronized void setRemoteWebDriverMap(RemoteWebDriver driver) {
        remoteWebDriverMap.put((int) (long) (Thread.currentThread().getId()), driver);
    }

    public static synchronized WebDriver getWebDriver() {
        return webDriverMap.get((int) (long) (Thread.currentThread().getId()));
    }

    public static synchronized void setWebDriverMap(WebDriver driver) {
        webDriverMap.put((int) (long) (Thread.currentThread().getId()), driver);
    }
}
