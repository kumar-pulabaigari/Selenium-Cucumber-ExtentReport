package frameworkUtili;

import commonFunctions.localDriverInitialization;
import commonFunctions.remoteDriverInitialization;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestContext;

/**
 * Created by Vinay on 6/15/2017.
 */
public class driver {

    public WebDriver getDriver(){
        ITestContext context = configurationManager.getITestContext();
        String environmentName= context.getCurrentXmlTest().getParameter("environmentName");
        String browserName = context.getCurrentXmlTest().getParameter("browserName");
        String browserVersion = context.getCurrentXmlTest().getParameter("browserVersion");

        if(browserName.contains("remote") || browserName.contains("Remote")){
            remoteDriverInitialization remoteDriverInitialization = new remoteDriverInitialization();
            RemoteWebDriver remoteDriver = null;
            try{
                remoteDriver = configurationManager.getRemoteWebDriver();
            }catch(Exception ex){

            }
            if(remoteDriver != null) {
                return  remoteDriver;
            } else {
                remoteDriver = remoteDriverInitialization.remoteInitiate();
                configurationManager.setRemoteWebDriverMap(remoteDriver);
                return remoteDriver;
            }
        } else {
            localDriverInitialization localDriverInitialization = new localDriverInitialization();
            WebDriver driver = null;
            try{
                driver = configurationManager.getWebDriver();
            }catch(Exception ex){

            }
            if(driver != null) {
                return  driver;
            } else {
                driver = localDriverInitialization.setDriverLocal();
                configurationManager.setWebDriverMap(driver);
                return driver;
            }
        }
    }
}
