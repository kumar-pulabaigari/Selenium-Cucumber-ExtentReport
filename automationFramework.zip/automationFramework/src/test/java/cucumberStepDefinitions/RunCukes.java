package cucumberStepDefinitions;

import cucumber.api.testng.CucumberFeatureWrapper;
import extentReport.ExtentManager;
import extentReport.ExtentTestManager;
import frameworkUtili.configurationManager;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import cucumber.api.CucumberOptions;
import cucumber.api.testng.TestNGCucumberRunner;

@CucumberOptions( features = {"src/test/java/featureFile/findYourFeature.feature"},
		   format = {"pretty", "html:target/results1.html",  "json:target/result1.json"}
)

public class RunCukes {
	private TestNGCucumberRunner testNGCucumberRunner;

	@BeforeClass(alwaysRun = true)
	public void setUpClass(ITestContext context) throws Exception {
        ExtentTestManager.extent = ExtentManager.getReporter();
		configurationManager.setITestContext(context);
		System.out.println("Parameter Value: " + context.getCurrentXmlTest().getParameter("browserName"));
		testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
	}

	@Test(groups = "cucumber", description = "Runs Cucumber Feature", dataProvider = "features")
	public void feature(CucumberFeatureWrapper cucumberFeature, ITestContext context) {
		testNGCucumberRunner.runCucumber(cucumberFeature.getCucumberFeature());
	}

	@DataProvider
	public Object[][] features() {
		return testNGCucumberRunner.provideFeatures();
	}

	@AfterClass(alwaysRun = true)
	public void tearDownClass() throws Exception {
		testNGCucumberRunner.finish();
        ExtentManager.getReporter().flush();
	}
}