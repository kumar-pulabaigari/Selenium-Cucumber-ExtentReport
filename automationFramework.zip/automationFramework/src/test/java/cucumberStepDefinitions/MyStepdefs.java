package cucumberStepDefinitions;

import com.relevantcodes.extentreports.LogStatus;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import extentReport.ExtentManager;
import extentReport.ExtentTestManager;
import frameworkUtili.configurationManager;
import frameworkUtili.driver;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import java.util.Collection;

public class MyStepdefs {

    @Before
    public void before(Scenario scenario){
        Collection<String> category = scenario.getSourceTagNames();
        ITestContext context = configurationManager.getITestContext();
        String testCaseName = "";
        ExtentTestManager.extent = ExtentManager.getReporter();
        int count =1;
        try{
            if(! context.getCurrentXmlTest().getParameter("automationName").isEmpty()){
                testCaseName =context.getCurrentXmlTest().getParameter("automationName") + "_";
                testCaseName = testCaseName.trim();
                category.add(context.getCurrentXmlTest().getParameter("automationName"));
            }
        }catch(Exception ex){

        }
        try {
            if (!context.getCurrentXmlTest().getParameter("environmentName").isEmpty()) {
                testCaseName = testCaseName + context.getCurrentXmlTest().getParameter("environmentName") + "_";
                category.add(context.getCurrentXmlTest().getParameter("environmentName"));
                testCaseName = testCaseName.trim();
            }
        }catch(Exception ex){

        }

        try{
            if(! context.getCurrentXmlTest().getParameter("browserName").isEmpty()){
                testCaseName= testCaseName+ context.getCurrentXmlTest().getParameter("browserName");
                testCaseName=testCaseName.trim();
                category.add(context.getCurrentXmlTest().getParameter("browserName"));
            }
        }catch(Exception ex){

        }

        try{
            if(testCaseName.trim().isEmpty()) {
                testCaseName= scenario.getName();
            } else {
                testCaseName= testCaseName+ "_"+ scenario.getName();
            }
        }catch(Exception ex){

        }

        do {
            if(configurationManager.testCaseNameList.contains(testCaseName+ "_" + count)) {
                count++;
            }else{
                configurationManager.testCaseNameList.add(testCaseName+ "_" + count);
                ExtentTestManager.startTest(testCaseName+ "_" + count);
                break;
            }
        }while(true);

        ExtentTestManager.assignCategory(category);
        ExtentTestManager.getTest().log(LogStatus.INFO, "scenario started..." + scenario.getName());
        configurationManager.setTestCaseName(scenario.getName());
        FolderName(scenario, context);
    }

    @Given("^Select the Browser$")
    public void selectTheBrowser() throws Throwable {
        System.out.println("User is on " + getClass().toString());
        driver wDriver= new driver();
        WebDriver driver= wDriver.getDriver();
        driver.get("http://google.com");
        ExtentTestManager.write(LogStatus.INFO, driver.getTitle());
        new pages.onlineCarInsurance.findYourCarPage().enterPolicyStartDatePicker();
    }

    @Given("^User is on a provided URL page$")
    public void userisonaprovidedURLpage() throws Throwable {
        System.out.println("User is on " + getClass().toString());
    }

    @Then("^Title should be matched with expected value$")
    public void titleShouldBeMatchedWithExpectedValue() throws Throwable {
        System.out.println("User is on " + getClass().toString());
    }

    @After
    public void after(Scenario scenario) {
        if (scenario.isFailed()) {
            ExtentTestManager.write(scenario, LogStatus.FAIL, "Test case failed");
        } else {
            ExtentTestManager.write(scenario, LogStatus.PASS, "Test passed");
        }
        ExtentManager.getReporter().endTest(ExtentTestManager.getTest());
        ExtentManager.getReporter().flush();
    }

    private boolean FolderName(Scenario scenario, ITestContext context) {
//        ITestContext context = configurationManager.getITestContext();
        int count=1;
        String screenShotPath ="";
        try {
            if (!context.getCurrentXmlTest().getParameter("automationName").isEmpty()) {
                screenShotPath = context.getCurrentXmlTest().getParameter("automationName") + "\\";
                screenShotPath = screenShotPath.trim();
            }
        }catch(Exception ex){

        }

        try{
            if(! context.getCurrentXmlTest().getParameter("environmentName").isEmpty()){
                screenShotPath= context.getCurrentXmlTest().getParameter("environmentName") + "\\";
                screenShotPath=screenShotPath.trim();
            }
        }catch(Exception ex){

        }

        try{
            if(! context.getCurrentXmlTest().getParameter("browserName").isEmpty()){
                screenShotPath= context.getCurrentXmlTest().getParameter("browserName") + "\\";
                screenShotPath=screenShotPath.trim();
            }
        }catch(Exception ex){

        }

        try{
            if(screenShotPath.trim().isEmpty()) {
                screenShotPath= scenario.getName();
            } else {
                screenShotPath = screenShotPath + scenario.getName();
            }
        }catch(Exception ex){

        }

        do {
            if(configurationManager.screenShotPathList.contains(screenShotPath+ "_" + count)) {
                count++;
            }else{
                configurationManager.screenShotPathList.add(screenShotPath+ "_" + count);
                configurationManager.setScreenShotPath(screenShotPath+ "_" + count);
                break;
            }
        }while(true);
        return true;
    }

}