package commonFunctions;

import java.io.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import com.relevantcodes.extentreports.LogStatus;
import extentReport.ExtentTestManager;
import frameworkUtili.configurationManager;
import org.apache.commons.io.FileUtils;
import org.apache.poi.xwpf.usermodel.Document;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CommonBehaviour {


	public String screenshot(WebDriver driver){
		String sFolderPath= configurationManager.getScreenShotPath();
		Integer number=0;
		try{
            number=new File(sFolderPath).listFiles().length;
        } catch (Exception ex){
		    number=0;
        }
		String sFilePath = sFolderPath + Integer.toString(number) + ".png";
		getScreenShot(driver, sFilePath);
		return sFilePath;
    }

    public String screenshot(RemoteWebDriver driver){
        String sFolderPath= configurationManager.getScreenShotPath();
        Integer number=0;
        try{
            number=new File(sFolderPath).listFiles().length;
        } catch (Exception ex){
            number=0;
        }
        String sFilePath = sFolderPath + Integer.toString(number) + ".png";
        getScreenShot(driver, sFilePath);
        return sFilePath;
    }

    public String reportScreenshot(WebDriver driver){
        String sFilePath = screenshot(driver);
        ExtentTestManager.addScreenShots(sFilePath);
        return sFilePath;
    }

    public String reportScreenshot(RemoteWebDriver driver){
        String sFilePath = screenshot(driver);
        ExtentTestManager.addScreenShots(sFilePath);
        return sFilePath;
    }

    public boolean imageDocumentReport() {
        String sFilePath=imageDocument();
        ExtentTestManager.getTest().log(LogStatus.INFO, "Complete screenshot path" , sFilePath);
        return true;
    }

	public String imageDocument () {
        String sFolderPath= configurationManager.getScreenShotPath();
        String sFilePath = sFolderPath + "screenShots.doc";
        FileOutputStream out=null;
        Integer number=0;
        XWPFDocument docx = new XWPFDocument();
        XWPFParagraph par = docx.createParagraph();
        XWPFRun run = par.createRun();
        run.setText(sFolderPath);
        run.setFontSize(13);

        try{
            number=new File(sFolderPath).listFiles().length;
        }catch (Exception ex){
            number=0;
        }

        try{
            out = new FileOutputStream(sFilePath);
        } catch (IOException ex){
            System.out.println(ex.getMessage());
            return "";
        }

        for(int i=0; i<number ; i++){
            try{
                XWPFParagraph par1 = docx.createParagraph();
                XWPFRun run1 = par1.createRun();
                InputStream pic = new FileInputStream(sFolderPath + Integer.toString(i) + ".jpeg");
                run1.addPicture(pic, Document.PICTURE_TYPE_JPEG, "3", 0, 0);
                docx.write(out);
                out.close();
                pic.close();
            }catch (Exception ex){
                System.out.println(ex.getMessage());
            }
        }

        try{
            out.close();
        } catch(IOException ex) {
            System.out.println(ex.getMessage());
            return "";
        }
        return sFilePath;
    }

    public void checkTitle(final WebDriver driver, String expectedTitle) {
        if(driver.getTitle().equals(expectedTitle)) {
            ExtentTestManager.getTest().log(LogStatus.PASS, "Check page title", "Page title is " + expectedTitle);
        } else {
            ExtentTestManager.getTest().log(LogStatus.FAIL, "Check page title", "Incorrect login page title " + driver.getTitle());
        }
    }

    public void checkTitle(final RemoteWebDriver driver, String expectedTitle) {
        if(driver.getTitle().equals(expectedTitle)) {
            ExtentTestManager.getTest().log(LogStatus.PASS, "Check page title", "Page title is " + expectedTitle);
        } else {
            ExtentTestManager.getTest().log(LogStatus.FAIL, "Check page title", "Incorrect login page title " + driver.getTitle());
        }
    }

	public boolean isExist(final WebDriver driver, final By locator) {
		try{
    		WebDriverWait wait = new WebDriverWait(driver, 15);
			WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
            if(element.isDisplayed()){
                return true;
            } else{
                return false;
            }
        }catch(Exception ex){
            return false;
        }
	}


	public boolean isExist(final RemoteWebDriver driver, final By locator) {
		try{
			WebDriverWait wait = new WebDriverWait(driver, 15);
			WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
			if(element.isDisplayed()){
				return true;
			} else{
				return false;
			}
		}catch(Exception ex){
			return false;
		}
    }

	public boolean isClickable(final WebDriver driver, final By locator) {
		WebDriverWait wait = new WebDriverWait(driver, 15);
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(locator));
		return element.isEnabled();
	}

	public boolean isClickable(final RemoteWebDriver driver, final By locator) {
		WebDriverWait wait = new WebDriverWait(driver, 15);
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(locator));
		return element.isEnabled();
	}

	public boolean isSelectable(final WebDriver driver, final By locator) {
		WebDriverWait wait = new WebDriverWait(driver, 15);
		return wait.until(ExpectedConditions.elementToBeSelected(locator));
	}

	public boolean isSelectable(final RemoteWebDriver driver, final By locator) {
		WebDriverWait wait = new WebDriverWait(driver, 15);
		return wait.until(ExpectedConditions.elementToBeSelected(locator));
	}

	public Date stringToDate(String formatter, String value) {
		DateFormat df = new SimpleDateFormat(formatter);
		Date startDate = null;
		try {
			startDate = df.parse(value);

		} catch (ParseException e) {
			e.printStackTrace();
		}
		return startDate;
	}

	public boolean click(By by, RemoteWebDriver driver) {
		try {
			if (isClickable(driver, by)) {
				driver.findElement(by).click();
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public boolean jClick(By by, RemoteWebDriver driver) {
		try {
			WebElement element = driver.findElement(by);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", element);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public boolean type(By by, RemoteWebDriver driver, String message) {
		try {
			if (driver.findElement(by).isEnabled()) {
				driver.findElement(by).sendKeys(message);
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public boolean jType(By by, RemoteWebDriver driver, String message) {
		try {
			WebElement element = driver.findElement(by);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].setAttribute('value', '" + message + "')", element);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public boolean selectValue(By by, RemoteWebDriver driver, String message) {
		try {
			if (isSelectable(driver, by)) {
				Select dropdown = new Select(driver.findElement(by));
				try {
					dropdown.selectByValue(message);
				} catch (Exception e) {
					e.printStackTrace();
					for (int i = 0; i < dropdown.getOptions().size(); i++) {
						if (dropdown.getOptions().get(i).getText().trim().equalsIgnoreCase(message.trim())) {
							dropdown.selectByIndex(i);
							break;
						}
					}
				}
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public boolean selectByIndex(By by, RemoteWebDriver driver, int index) {
		try {
			if (isSelectable(driver, by)) {
				Select dropdown = new Select(driver.findElement(by));
				dropdown.selectByIndex(index);
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public boolean click(String fieldName, By by, WebDriver driver) {
		try {
			if (isClickable(driver, by)) {
				driver.findElement(by).click();
				ExtentTestManager.write(LogStatus.PASS, "Click" , fieldName +  " has been a clicked.");
				return true;
			} else {
				ExtentTestManager.write(LogStatus.FAIL, "Click" , fieldName +  " has not been a clicked.");
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			ExtentTestManager.write(LogStatus.FAIL, "Click" , fieldName +  " has not been a clicked.");
			return false;
		}
	}

	public boolean jClick(By by, WebDriver driver) {
		try {
			WebElement element = driver.findElement(by);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", element);
			ExtentTestManager.write(LogStatus.PASS, "Click" , by.toString() +  " has been a clicked.");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public boolean type(String fieldName, By by, WebDriver driver, String message) {
		try {
			if (driver.findElement(by).isEnabled()) {
				driver.findElement(by).sendKeys(message);
				ExtentTestManager.write(LogStatus.PASS, "Type" , fieldName +  " has been entered with a message :" + message);
				return true;
			} else {
				ExtentTestManager.write(LogStatus.FAIL, "Type" , fieldName +  " has not been entered with a message :" + message);
				return false;
			}

		} catch (Exception e) {
			e.printStackTrace();
			ExtentTestManager.write(LogStatus.FAIL, "Type" , fieldName +  " has not been entered with a message :" + message);
			return false;
		}
	}

	public boolean jType(String fieldName, By by, WebDriver driver, String message) {
		try {
			WebElement element = driver.findElement(by);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].setAttribute('value', '" + message + "')", element);
			ExtentTestManager.write(LogStatus.PASS, "Type" , fieldName +  " has been entered with a message :" + message);
			return true;
		} catch (Exception e) {
			ExtentTestManager.write(LogStatus.FAIL, "Type" , fieldName +  " has not been entered with a message :" + message);
			e.printStackTrace();
			return false;
		}
	}

	public boolean selectValue(By by, WebDriver driver, String message) {
		try {
			if (isSelectable(driver, by)) {
				Select dropdown = new Select(driver.findElement(by));
				try {
					dropdown.selectByValue(message);
				} catch (Exception e) {
					e.printStackTrace();
					for (int i = 0; i < dropdown.getOptions().size(); i++) {
						if (dropdown.getOptions().get(i).getText().trim().equalsIgnoreCase(message.trim())) {
							dropdown.selectByIndex(i);
							break;
						}
					}
				}
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public boolean selectByIndex(By by, WebDriver driver, int index) {
		try {
			if (isSelectable(driver, by)) {
				Select dropdown = new Select(driver.findElement(by));
				dropdown.selectByIndex(index);
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public String getAttribute(By by, WebDriver driver, String attribute) {
		String returnValue = "";
		try {
			if (isSelectable(driver, by)) {
				returnValue = driver.findElement(by).getAttribute(attribute);
				return returnValue;
			} else {
				return returnValue;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return returnValue;
		}
	}

	public String getAttribute(By by, RemoteWebDriver driver, String attribute) {
		String returnValue = "";
		try {
			if (isSelectable(driver, by)) {
				returnValue = driver.findElement(by).getAttribute(attribute);
				return returnValue;
			} else {
				return returnValue;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return returnValue;
		}
	}

	public boolean getScreenShot(WebDriver driver, String fileName) {
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		// The below method will save the screen shot in d drive with name
		// "screenshot.png"
		try {
			FileUtils.copyFile(scrFile, new File(fileName));
		} catch (IOException e) {
			System.out.println("Exception is "+ e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean getScreenShot(RemoteWebDriver driver, String fileName) {
		WebDriver augmentedDriver = new Augmenter().augment(driver);
		File scrFile = ((TakesScreenshot) augmentedDriver).getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(scrFile, new File(fileName));
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean navigateURL(WebDriver driver, String url) {
		driver.get(url);
		return true;
	}

	public boolean navigateURL(RemoteWebDriver driver, String url) {
		driver.get(url);
		return true;
	}

	public String getTitle(WebDriver driver) {
		return driver.getTitle();
	}

	public String getTitle(RemoteWebDriver driver) {
		return driver.getTitle();
	}
}
