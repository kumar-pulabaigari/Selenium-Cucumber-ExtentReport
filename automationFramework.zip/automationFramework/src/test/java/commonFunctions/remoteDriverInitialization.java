package commonFunctions;

import com.relevantcodes.extentreports.LogStatus;
import extentReport.ExtentTestManager;
import frameworkUtili.configurationManager;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestContext;
import java.net.URL;
import java.util.concurrent.TimeUnit;

public class remoteDriverInitialization {
    private loadPropertyFile applicationProperty= new loadPropertyFile("//resources//application.properties");
    DesiredCapabilities capabilities = new DesiredCapabilities();

    public RemoteWebDriver remoteInitiate(){
        String environmentName, browserName,automationName, browserVersion, OperatingSystem;
        RemoteWebDriver driver =null;
        ITestContext context = configurationManager.getITestContext();
        environmentName= context.getCurrentXmlTest().getParameter("environmentName");
        browserName = context.getCurrentXmlTest().getParameter("browserName");
        browserVersion = context.getCurrentXmlTest().getParameter("browserVersion");
        try{
            OperatingSystem = context.getCurrentXmlTest().getParameter("browserVersion");
        } catch(Exception ex){
            OperatingSystem ="";
        }
        if (browserName.trim().equalsIgnoreCase("ie") || browserName.trim().equalsIgnoreCase("internet explorer")) {
            capabilities.setBrowserName("internet explorer");
        } else if (browserName.trim().equalsIgnoreCase("firefox") || browserName.trim().equalsIgnoreCase("ff")) {
            capabilities.setBrowserName("firefox");
        } else {
            capabilities.setBrowserName("chrome");
        }

        if (browserVersion.trim().isEmpty()) {

        } else {
            capabilities.setVersion(browserVersion);
        }

        if (OperatingSystem.trim().isEmpty()) {

        } else {
            if (OperatingSystem.trim().equalsIgnoreCase("Windows")) {
                capabilities.setPlatform(Platform.WINDOWS);
            } else if (OperatingSystem.trim().equalsIgnoreCase("XP")) {
                capabilities.setPlatform(Platform.XP);
            } else if (OperatingSystem.trim().equalsIgnoreCase("MAC")) {
                capabilities.setPlatform(Platform.MAC);
            } else if (OperatingSystem.trim().equalsIgnoreCase("Linux")) {
                capabilities.setPlatform(Platform.LINUX);
            } else if (OperatingSystem.trim().equalsIgnoreCase("Unix")) {
                capabilities.setPlatform(Platform.UNIX);
            }
        }

        switch(environmentName.toLowerCase()) {
            case "local":
                try {
                    String node="http://" +applicationProperty.getPropertyValue("local.remote.server") + ":" ;
                    node=node +applicationProperty.getPropertyValue("local.remote.port") + "/wd/hub";
                    driver = new RemoteWebDriver(new URL(node), capabilities);
                    ExtentTestManager.write(LogStatus.INFO, "Remote web driver has been initiated.");
                } catch (Exception e) {
                    ExtentTestManager.getTest().log(LogStatus.FAIL, "Remote web driver has not been initiated.");
                    ExtentTestManager.getTest().log(LogStatus.INFO, "Exception details" + e.toString());
                }
                break;

            case "perfecto":
                try {
                    String node = applicationProperty.getPropertyValue("perfecto.remote.server");
                    String userName = applicationProperty.getPropertyValue("perfecto.username");
                    String password = applicationProperty.getPropertyValue("perfecto.password");
                    capabilities.setCapability("user", userName);
                    capabilities.setCapability("password", password);
                    driver = new RemoteWebDriver(new URL(node), capabilities);
                    ExtentTestManager.write(LogStatus.INFO, "Remote web driver has been initiated.");
                } catch (Exception e) {
                    ExtentTestManager.getTest().log(LogStatus.FAIL, "Remote web driver has not been initiated.");
                    ExtentTestManager.getTest().log(LogStatus.INFO, "Exception details" + e.toString());
                }
                break;
        }
        driver.manage().timeouts().pageLoadTimeout(Integer.parseInt(applicationProperty.getPropertyValue("pageLoadTime")), TimeUnit.SECONDS);
        driver.manage().timeouts().setScriptTimeout(Integer.parseInt(applicationProperty.getPropertyValue("setScriptTimeout")), TimeUnit.SECONDS);
        driver.manage().timeouts().implicitlyWait(Integer.parseInt(applicationProperty.getPropertyValue("implicitlyWait")), TimeUnit.SECONDS);
        return driver;
    }

}
