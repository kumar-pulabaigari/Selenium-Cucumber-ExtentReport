package commonFunctions;

import com.relevantcodes.extentreports.LogStatus;
import extentReport.ExtentTestManager;
import frameworkUtili.configurationManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.ITestContext;

import java.util.concurrent.TimeUnit;

/**
 * Created by Vinay on 6/14/2017.
 */
public class localDriverInitialization {
    private loadPropertyFile applicationProperty= new loadPropertyFile("resources/application.properties");

    public WebDriver setDriverLocal() {
        ITestContext context = configurationManager.getITestContext();
        String environmentName= context.getCurrentXmlTest().getParameter("environmentName");
        String BrowserName = context.getCurrentXmlTest().getParameter("browserName");
        String browserVersion = context.getCurrentXmlTest().getParameter("browserVersion");
        WebDriver driver;
        if (BrowserName.trim().equalsIgnoreCase("ie") || BrowserName.trim().equalsIgnoreCase("internet explorer")) {
            System.setProperty("webdriver.ie.driver", System.getProperty("user.dir") + applicationProperty.getPropertyValue("webdriver.ie.driver"));
            driver = new InternetExplorerDriver();
            try{
                Thread.sleep(3000);
            }catch(Exception e){
                e.printStackTrace();
            }
            ExtentTestManager.write(LogStatus.INFO, "IE Browser has been initiated in local");
        } else if (BrowserName.trim().equalsIgnoreCase("Edge") || BrowserName.trim().equalsIgnoreCase("IE Edge")) {
            System.setProperty("webdriver.edge.driver", System.getProperty("user.dir") + applicationProperty.getPropertyValue("webdriver.edge.driver"));
            driver = new EdgeDriver();
            try{
                Thread.sleep(3000);
            }catch(Exception e){
                e.printStackTrace();
            }
            ExtentTestManager.write(LogStatus.INFO, "Edge Browser has been initiated in local");
        } else if (BrowserName.trim().equalsIgnoreCase("firefox") || BrowserName.trim().equalsIgnoreCase("ff")) {
            System.setProperty("webdriver.gecko.driver",
                    System.getProperty("user.dir") + applicationProperty.getPropertyValue("webdriver.gecko.driver"));
            driver = new FirefoxDriver();
            ExtentTestManager.write(LogStatus.INFO, "Firefox Browser has been initiated in local");
        } else {
            System.setProperty("webdriver.chrome.driver",
                    System.getProperty("user.dir") + applicationProperty.getPropertyValue("webdriver.chrome.driver"));
            driver = new ChromeDriver();
            ExtentTestManager.write(LogStatus.INFO, "Chrome Browser has been initiated in local");
        }

        driver.manage().timeouts().pageLoadTimeout(Integer.parseInt(applicationProperty.getPropertyValue("pageLoadTime")), TimeUnit.SECONDS);
        driver.manage().timeouts().setScriptTimeout(Integer.parseInt(applicationProperty.getPropertyValue("setScriptTimeout")), TimeUnit.SECONDS);
        driver.manage().timeouts().implicitlyWait(Integer.parseInt(applicationProperty.getPropertyValue("implicitlyWait")), TimeUnit.SECONDS);
        return driver;
    }

}
