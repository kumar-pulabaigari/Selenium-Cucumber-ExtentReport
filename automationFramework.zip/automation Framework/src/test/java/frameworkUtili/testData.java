package frameworkUtili;

import com.relevantcodes.extentreports.LogStatus;
import commonFunctions.ExcelReader;
import extentReport.ExtentTestManager;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;

import java.util.Map;

/**
 * Created by Sreehari_M on 6/29/2017.
 */
public class testData {
    public String getTestData(String columnName) {
        Map<String, String> mDataRow = null;
        try{
            mDataRow = configurationManager.getTestDataMap();
        }catch(Exception ex){

        }

        if(mDataRow == null){
            ITestContext context = configurationManager.getITestContext();
            String testCaseName = configurationManager.getTestCaseName();
            ExcelReader reader = new ExcelReader();
            mDataRow=reader.readDataReturnMap(testCaseName);
            configurationManager.setTestDataMap(mDataRow);
        }

        try{
            if (mDataRow.get(columnName.trim()).isEmpty() || mDataRow.get(columnName.trim()) == null) {
                ExtentTestManager.getTest().log(LogStatus.INFO, "Column  hasn't been found, hence the value is going to be returned is blank.");
                return "";
            } else {
                return mDataRow.get(columnName.trim());
            }
        }catch(Exception ex){
            return "";
        }
    }
}
