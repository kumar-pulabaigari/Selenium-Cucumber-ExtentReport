package testNgDefinitions;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import extentReport.ExtentTestManager;
import frameworkUtili.configurationManager;
import frameworkUtili.driver;
import frameworkUtili.testData;
import org.dom4j.Document;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.Test;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
/**
 * Created by Vinay on 5/13/2017.
 */
public class sampleTest extends testNGMaster{

    @Test
    public void validatorSuccess(ITestContext context){
        before("validatorSuccess");
        String SOAPUrl = "http://tvmatp333478d:8001/cibil/validatator";
        testData data=new testData();
        String userName=data.getTestData("UserName");
        String Password=data.getTestData("Password");
        try{
            URL oURL = new URL(SOAPUrl);
            HttpURLConnection con = (HttpURLConnection) oURL.openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-type", "text/xml; charset=utf-8");
            con.setRequestProperty("User-Agent", "Mozilla/5.0");
            ExtentTestManager.write(LogStatus.INFO, "User Name", " IS " + userName);
            ExtentTestManager.write(LogStatus.INFO, "Password", " IS " + Password);
            con.setDoOutput(true);
            String reqXML ="<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
                    "    <soapenv:Header/>\n" +
                    "    <soapenv:Body>\n" +
                    "        <ws_LookUp>\n" +
                    "            <lookUpRequest>\n" +
                    "                <UserId>"+userName+"</UserId>\n" +
                    "                <Password>"+Password+"</Password>\n" +
                    "                <lookUpInput>\n" +
                    "                    <Name>ABC Corporation</Name>\n" +
                    "                    <IDENTIFICATION_TYPE>PAN</IDENTIFICATION_TYPE>\n" +
                    "                    <NUMBER>ABCDE1234P</NUMBER>\n" +
                    "                    <Customer_type>P</Customer_type>\n" +
                    "                </lookUpInput>\n" +
                    "            </lookUpRequest>\n" +
                    "        </ws_LookUp>\n" +
                    "    </soapenv:Body>\n" +
                    "</soapenv:Envelope>";
            OutputStream os = con.getOutputStream();
            os.write(reqXML.getBytes());
            os.flush();
            os.close();

            int responseCode = con.getResponseCode();
            System.out.println("POST Response Code :: " + responseCode);
            if (responseCode == HttpURLConnection.HTTP_OK) { //success
                BufferedReader in = new BufferedReader(new InputStreamReader(
                        con.getInputStream()));
                ExtentTestManager.write(LogStatus.PASS, "HTTP Response ", " is" + responseCode);
                String inputLine;
                StringBuffer response = new StringBuffer();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();
                // print result
                System.out.println(response.toString());
                org.w3c.dom.Document doc = convertStringToDocument(response.toString());
                System.out.println(doc.getElementsByTagName("soapenv:Body").toString());


            } else {
                System.out.println("POST request not worked");
            }


        }catch(Exception ex){
            System.out.println("Exception is " + ex.getMessage());
        }

    }
}
